:orphan:

.. _sections_demo_1:

Sections Demo 1
===============

.. image:: sections_demo_1.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sections

.. literalinclude:: ../../../arcade/examples/sections_demo_1.py
    :caption: sections_demo_1.py
    :linenos:
