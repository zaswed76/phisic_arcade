:orphan:

.. _stress_test_collision:

Collision Stress Test
=====================

.. image:: stress_test_collision.png
    :width: 600px
    :align: center
    :alt: Screenshot of stress test example

.. literalinclude:: ../../../arcade/examples/perf_test/stress_test_collision_arcade.py
    :caption: stress_test_collision_arcade.py
    :linenos:
