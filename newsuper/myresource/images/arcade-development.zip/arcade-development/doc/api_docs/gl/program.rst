
.. py:currentmodule:: arcade

Program
=======

Program
-------

.. autoclass:: arcade.gl.Program
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

Program Members
---------------

Uniform
~~~~~~~

.. autoclass:: arcade.gl.uniform.Uniform
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

UniformBlock
~~~~~~~~~~~~

.. autoclass:: arcade.gl.uniform.UniformBlock
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource
