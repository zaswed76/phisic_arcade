:orphan:

.. _easing_example_2:

Easing Example 2
================

.. image:: easing_example_2.png
    :width: 600px
    :align: center
    :alt: Easing Example

Source
------
.. literalinclude:: ../../../arcade/examples/easing_example_2.py
    :caption: easing_example.py
    :linenos:
