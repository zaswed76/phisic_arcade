:orphan:

.. _sound_demo:

Sound Demo
==========

.. image:: sound_demo.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sound demo

.. literalinclude:: ../../../arcade/examples/sound_demo.py
    :caption: sound_demo.py
    :linenos:
