:orphan:

.. _sprite_move_keyboard:

Sprite Move By Keyboard
=======================

.. image:: sprite_move_keyboard.png
    :width: 600px
    :align: center
    :alt: Screen shot of moving a sprite by keyboard

.. literalinclude:: ../../../arcade/examples/sprite_move_keyboard.py
    :caption: sprite_move_keyboard.py
    :linenos:
    :emphasize-lines: 25-44, 96-97, 99-110, 112-122
