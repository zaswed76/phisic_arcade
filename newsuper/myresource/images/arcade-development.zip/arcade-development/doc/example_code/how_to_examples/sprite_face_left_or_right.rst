:orphan:

.. _sprite_face_left_or_right:

Sprite: Face Left or Right
==========================

.. image:: sprite_face_left_or_right.png
    :width: 75%

.. literalinclude:: ../../../arcade/examples/sprite_face_left_or_right.py
    :caption: sprite_face_left_or_right.py
    :linenos:
    :emphasize-lines: 23-25, 33-45, 51-55
