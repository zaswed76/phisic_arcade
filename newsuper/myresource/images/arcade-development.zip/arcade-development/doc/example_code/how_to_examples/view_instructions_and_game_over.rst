:orphan:

.. _view_instructions_and_game_over:

Using Views for Instruction and Game Over Screens
=================================================

You might also want to check out :ref:`view-tutorial`.

.. literalinclude:: ../../../arcade/examples/view_instructions_and_game_over.py
    :caption: view_instructions_and_game_over.py
    :linenos:
