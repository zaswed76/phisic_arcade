:orphan:

.. _sprite_explosion_particles:

Sprite Explosions Particles
===========================

.. image:: sprite_explosion_particles.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to shoot things

.. literalinclude:: ../../../arcade/examples/sprite_explosion_particles.py
    :caption: sprite_explosion_particles.py
    :linenos:
