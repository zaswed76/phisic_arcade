from arcade.management import show_info


if __name__ == "__main__":
    show_info()
