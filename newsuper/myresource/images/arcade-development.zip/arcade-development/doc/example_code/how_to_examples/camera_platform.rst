:orphan:

.. _camera_platform:

Camera Use in a Platformer
==========================

.. image:: camera_platform.png
    :width: 600px
    :align: center
    :alt: Screen shot of using a scrolling window

.. literalinclude:: ../../../arcade/examples/camera_platform.py
    :caption: camera_platform.py
    :linenos:
