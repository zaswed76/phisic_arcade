:orphan:

.. _sound_speed_demo:

Sound Demo
==========

.. image:: sound_speed_demo.png
    :width: 600px
    :align: center
    :alt: Screen shot of using the sound speed demo

.. literalinclude:: ../../../arcade/examples/sound_speed_demo.py
    :caption: sound_speed_demo.py
    :linenos:
