:orphan:

.. _sprite_collect_rotating:

Animated Sprites
================

.. image:: sprite_collect_rotating.png
    :width: 600px
    :align: center
    :alt: Screen shot of rotating sprites

.. literalinclude:: ../../../arcade/examples/sprite_collect_rotating.py
    :caption: sprite_collect_rotating.py
    :linenos:
