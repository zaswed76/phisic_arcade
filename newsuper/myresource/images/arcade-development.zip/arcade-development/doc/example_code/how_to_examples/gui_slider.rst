:orphan:

.. _gui_slider:

GUI Slider
==========

.. image:: gui_slider.png
    :width: 600px
    :align: center
    :alt: Screen shot of a GUI slider in the example

.. literalinclude:: ../../../arcade/examples/gui_slider.py
    :caption: gui_slider.py
    :linenos:
