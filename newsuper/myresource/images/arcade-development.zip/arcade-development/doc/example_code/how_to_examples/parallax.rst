:orphan:

.. _parallax:

Parallax
========

.. image:: parallax.png
    :width: 600px
    :align: center
    :alt: Screen shot of a parallax example


.. literalinclude:: ../../../arcade/examples/parallax.py
    :caption: parallax.py
    :linenos:
