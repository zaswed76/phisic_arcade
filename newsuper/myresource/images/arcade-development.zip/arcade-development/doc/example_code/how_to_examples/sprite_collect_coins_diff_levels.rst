:orphan:

.. _example-sprite-collect-coins-diff-levels:

Different Levels of Clearing Coins
==================================

.. image:: sprite_collect_coins_diff_levels.gif
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_collect_coins_diff_levels.py
    :caption: sprite_collect_coins_diff_levels.py
    :linenos:
