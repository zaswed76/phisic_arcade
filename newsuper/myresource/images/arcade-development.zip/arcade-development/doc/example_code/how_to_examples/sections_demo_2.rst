:orphan:

.. _sections_demo_2:

Sections Demo 2
===============

.. image:: sections_demo_2.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sections

.. literalinclude:: ../../../arcade/examples/sections_demo_2.py
    :caption: sections_demo_2.py
    :linenos:
