:orphan:

.. _perspective:

Perspective
===========

.. image:: perspective.png
    :width: 600px
    :align: center
    :alt: Screen shot of a perspective example


.. literalinclude:: ../../../arcade/examples/perspective.py
    :caption: perspective.py
    :linenos:
