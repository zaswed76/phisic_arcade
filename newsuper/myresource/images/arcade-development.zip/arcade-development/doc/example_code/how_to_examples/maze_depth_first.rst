:orphan:

.. _maze_depth_first:

Creating a Depth First Maze
===========================

.. image:: maze_depth_first.png
    :width: 600px
    :align: center
    :alt: Screen shot of a maze created by depth first

.. literalinclude:: ../../../arcade/examples/maze_depth_first.py
    :caption: maze_depth_first.py
    :linenos:
