:orphan:

.. _asteroid_smasher:

Asteroid Smasher
================

This is a sample asteroid smasher game made with the Arcade library.

.. raw:: html

    <iframe width="420" height="315" src="https://www.youtube.com/embed/lz_DCy0_Sj0" frameborder="0" allowfullscreen></iframe>

.. literalinclude:: ../../../arcade/examples/asteroid_smasher.py
    :caption: asteroid_smasher.py
    :linenos:
