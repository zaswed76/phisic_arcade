:orphan:

.. _sprite_enemies_in_platformer:

Platformer With Enemies
=======================

.. image:: sprite_enemies_in_platformer.png
    :align: center


.. literalinclude:: ../../../arcade/examples/sprite_enemies_in_platformer.py
    :caption: sprite_enemies_in_platformer.py
    :linenos:
