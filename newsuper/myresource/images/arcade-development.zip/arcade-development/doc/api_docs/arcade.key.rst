.. _key:

arcade.key package
==================

Mapping of keyboard keys to values.

.. literalinclude:: ../../arcade/key/__init__.py