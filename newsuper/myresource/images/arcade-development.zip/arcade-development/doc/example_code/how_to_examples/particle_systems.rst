:orphan:

.. _particle_systems:

Particle Systems
================

.. image:: particle_systems.png
    :width: 255px
    :height: 255px
    :align: center
    :alt: Particle Systems

.. literalinclude:: ../../../arcade/examples/particle_systems.py
    :caption: particle_systems.py
    :linenos:
