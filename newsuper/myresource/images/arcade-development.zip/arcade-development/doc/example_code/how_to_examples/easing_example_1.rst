:orphan:

.. _easing_example_1:

Easing Example 1
================

.. image:: easing_example_1.png
    :width: 600px
    :align: center
    :alt: Easing Example

Source
------
.. literalinclude:: ../../../arcade/examples/easing_example_1.py
    :caption: easing_example.py
    :linenos:
