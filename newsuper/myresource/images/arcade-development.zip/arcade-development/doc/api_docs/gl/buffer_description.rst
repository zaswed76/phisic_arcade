
.. py:currentmodule:: arcade

BufferDescription
-----------------

.. autoclass:: arcade.gl.BufferDescription
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource
