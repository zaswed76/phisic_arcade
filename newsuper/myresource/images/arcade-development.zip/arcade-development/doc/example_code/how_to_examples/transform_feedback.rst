:orphan:

.. _transform_feedback:

Transform Feedback
==================

.. image:: transform_feedback.png
    :width: 600px
    :align: center
    :alt: Transform Feedback Example

.. literalinclude:: ../../../arcade/examples/transform_feedback.py
    :caption: transform_feedback.py
    :linenos:
