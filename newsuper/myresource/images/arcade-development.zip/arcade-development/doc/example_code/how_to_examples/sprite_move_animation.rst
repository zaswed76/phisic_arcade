:orphan:

.. _sprite_move_animation:

Move with a Sprite Animation
============================

.. image:: sprite_move_animation.png
    :align: center
    :alt: GIF animation of animated walking character.


.. literalinclude:: ../../../arcade/examples/sprite_move_animation.py
    :caption: sprite_move_animation.py
    :linenos:
    :emphasize-lines: 22-28, 31-38, 47-76, 78-97, 184-185
