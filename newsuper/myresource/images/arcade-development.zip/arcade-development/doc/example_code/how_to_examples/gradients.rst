:orphan:

.. _gradients:

Gradients Example
=================

.. image:: gradients.png
    :width: 600px
    :align: center
    :alt: Screenshot of a program demoing how to use gradients

.. literalinclude:: ../../../arcade/examples/gradients.py
    :caption: gradients.py
    :linenos:
