:orphan:

.. _view_screens_minimal:

Minimal Views Example
=====================

You might also want to check out :ref:`view-tutorial`.

.. literalinclude:: ../../../arcade/examples/view_screens_minimal.py
    :caption: view_screens_minimal.py
    :linenos:
