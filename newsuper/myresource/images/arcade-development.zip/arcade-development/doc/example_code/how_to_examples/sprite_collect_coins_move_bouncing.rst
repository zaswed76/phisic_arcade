:orphan:

.. _sprite_collect_coins_move_bouncing:

Collect Coins that are Bouncing
===============================

.. image:: sprite_collect_coins_move_bouncing.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_collect_coins_move_bouncing.py
    :caption: sprite_collect_coins_move_bouncing.py
    :linenos:
