:orphan:

.. _line_of_sight:

Line of Sight
==================================

.. image:: line_of_sight.png
    :width: 600px
    :align: center
    :alt: Line of Sight

.. literalinclude:: ../../../arcade/examples/line_of_sight.py
    :caption: line_of_sight.py
    :linenos:
