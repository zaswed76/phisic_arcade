:orphan:

.. _sprite_rooms:

Moving Between Different Rooms
==============================

.. image:: sprite_rooms.png
    :width: 600px
    :align: center
    :alt: Screenshot of moving between rooms with sprites

.. literalinclude:: ../../../arcade/examples/sprite_rooms.py
    :caption: sprite_rooms.py
    :linenos:
