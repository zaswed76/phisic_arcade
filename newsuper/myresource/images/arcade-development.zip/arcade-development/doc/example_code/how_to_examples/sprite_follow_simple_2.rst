:orphan:

.. _sprite_follow_simple_2:

Sprites That Follow The Player 2
================================

.. image:: sprite_follow_simple_2.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_follow_simple_2.py
    :caption: sprite_follow_simple_2.py
    :linenos:
