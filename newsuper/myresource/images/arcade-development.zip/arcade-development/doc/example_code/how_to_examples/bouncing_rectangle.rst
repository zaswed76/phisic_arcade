:orphan:

.. _bouncing_rectangle:

Bouncing Rectangle
==================

This shows how to animate an item you can draw using the drawing primitives.

.. image:: bouncing_rectangle.png
    :width: 70%

.. literalinclude:: ../../../arcade/examples/bouncing_rectangle.py
    :caption: bouncing_rectangle.py
    :linenos:
