:orphan:

.. _radar_sweep:

Radar Sweep
===========

.. image:: radar_sweep.png
    :width: 600px
    :align: center
    :alt: Screenshot of radar sweep example

.. literalinclude:: ../../../arcade/examples/radar_sweep.py
    :caption: radar_sweep.py
    :linenos:
