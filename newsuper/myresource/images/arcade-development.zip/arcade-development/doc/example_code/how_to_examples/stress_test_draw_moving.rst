:orphan:

.. _stress_test_draw_moving:

Draw Moving Sprites Stress Test
===============================

.. image:: stress_test_draw_moving.png
    :width: 600px
    :align: center
    :alt: Screenshot of stress test example

.. literalinclude:: ../../../arcade/examples/perf_test/stress_test_draw_moving_arcade.py
    :caption: stress_test_draw_moving_arcade.py
    :linenos:
