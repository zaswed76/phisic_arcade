:orphan:

.. _music_control_demo:

Music Control Demo
==================

.. image:: music_control_demo.png
    :width: 600px
    :align: center
    :alt: Screen shot of music control demo

.. literalinclude:: ../../../arcade/examples/music_control_demo.py
    :caption: music_control_demo.py
    :linenos:
