:orphan:

.. _sprite_collect_coins_move_circle:

Collect Coins that are Moving in a Circle
=========================================

.. image:: sprite_collect_coins_move_circle.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_collect_coins_move_circle.py
    :caption: sprite_collect_coins_move_circle.py
    :linenos:
