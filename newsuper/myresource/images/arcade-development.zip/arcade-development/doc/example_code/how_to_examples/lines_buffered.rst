:orphan:

.. _lines_buffered:

Using a Vertex Buffer Object With Lines
=======================================

.. image:: lines_buffered.png
    :width: 600px
    :align: center
    :alt: Screen shot of a maze created by depth first

.. literalinclude:: ../../../arcade/examples/lines_buffered.py
    :caption: lines_buffered.py
    :linenos:
