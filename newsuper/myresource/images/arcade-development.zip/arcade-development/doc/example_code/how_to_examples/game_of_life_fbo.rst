:orphan:

.. _game_of_life_fbo:

Game of Life with Frame Buffers
===============================

.. image:: game_of_life_fbo.png
    :width: 600px
    :align: center
    :alt: Screenshot of game of life

.. literalinclude:: ../../../arcade/examples/gl/game_of_life_colors.py
    :caption: game_of_life_colors.py
    :linenos:
