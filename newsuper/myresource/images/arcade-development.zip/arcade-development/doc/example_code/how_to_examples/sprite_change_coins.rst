:orphan:

.. _sprite_change_coins:

Change coins
============

.. image:: sprite_change_coins.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to change coins

.. literalinclude:: ../../../arcade/examples/sprite_change_coins.py
    :caption: sprite_change_coins.py
    :linenos:
