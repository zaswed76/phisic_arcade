:orphan:

.. _transitions:

Fade In/Out of Views
====================

You might also want to check out :ref:`view-tutorial`.

.. literalinclude:: ../../../arcade/examples/transitions.py
    :caption: transitions.py
    :linenos:
