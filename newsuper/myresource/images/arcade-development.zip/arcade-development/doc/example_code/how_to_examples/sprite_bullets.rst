:orphan:

.. _sprite_bullets:

Shoot Bullets Upwards
=====================

.. image:: sprite_bullets.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to shoot things

.. literalinclude:: ../../../arcade/examples/sprite_bullets.py
    :caption: sprite_bullets.py
    :linenos:
