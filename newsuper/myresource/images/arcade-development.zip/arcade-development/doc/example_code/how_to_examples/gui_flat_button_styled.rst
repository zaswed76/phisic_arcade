:orphan:

.. _gui_flat_button_styled:

Flat Text Button Styled
=======================

.. literalinclude:: ../../../arcade/examples/gui_flat_button_styled.py
    :caption: gui_flat_button_styled.py
    :linenos:
