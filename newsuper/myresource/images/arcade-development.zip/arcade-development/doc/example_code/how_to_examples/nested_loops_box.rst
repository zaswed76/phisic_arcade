:orphan:

.. _nested_loops_box:

Draw a Box with Nested Loops
============================

.. image:: nested_loops_box.png
    :width: 255px
    :height: 255px
    :align: center
    :alt: Screenshot of a program that shows an box with nested loops.

.. literalinclude:: ../../../arcade/examples/nested_loops_box.py
    :caption: nested_loops_box.py
    :linenos:
