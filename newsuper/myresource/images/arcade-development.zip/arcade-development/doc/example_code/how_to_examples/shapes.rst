:orphan:

.. _shapes-slow:

Bouncing Shapes
===============

.. image:: shapes.png
    :width: 600px
    :align: center
    :alt: Screenshot of Shapes example program

.. literalinclude:: ../../../arcade/examples/shapes.py
    :caption: shapes.py
    :linenos:
