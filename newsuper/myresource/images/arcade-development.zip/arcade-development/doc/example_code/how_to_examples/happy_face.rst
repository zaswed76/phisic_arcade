:orphan:

.. _happy_face:

Happy Face
==========

This example shows how to use the Arcade drawing commands.


.. image:: happy_face.png
    :width: 600px
    :align: center
    :alt: Screenshot of drawing example program



.. literalinclude:: ../../../arcade/examples/happy_face.py
    :caption: happy_face.py
    :linenos:
