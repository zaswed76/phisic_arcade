## Bug Report

## System Info

Run this and paste the output here: python -m arcade

### Actual behavior:

### Expected behavior:

### Steps to reproduce/example code:


## Enhancement request:

### What should be added/changed?

### What would it help with?


## Documentation request:

### What documentation needs to change? 

### Where is it located?

### What is wrong with it? How can it be improved?
