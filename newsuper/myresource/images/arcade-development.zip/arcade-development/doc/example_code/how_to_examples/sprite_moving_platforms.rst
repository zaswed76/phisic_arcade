:orphan:

.. _sprite_moving_platforms:

Moving Platforms
================

.. raw:: html

    <iframe width="420" height="315" src="https://www.youtube.com/embed/1Z4WP3zTAmc" frameborder="0" allowfullscreen></iframe>


.. literalinclude:: ../../../arcade/examples/sprite_moving_platforms.py
    :caption: sprite_moving_platforms.py
    :linenos:
