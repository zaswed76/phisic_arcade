:orphan:

.. _snow:

Falling Snow
============

.. image:: snow.png
    :width: 600px
    :align: center
    :alt: Screen shot of using using an array for snow

.. literalinclude:: ../../../arcade/examples/snow.py
    :caption: snow.py
    :linenos:
