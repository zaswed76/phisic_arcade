:orphan:

.. _light_demo:

Lighting Demo
=============

.. image:: light_demo.png
    :width: 600px
    :align: center
    :alt: Screen shot of a Defender clone with a bloom/glow effect.


.. literalinclude:: ../../../arcade/examples/light_demo.py
    :caption: light_demo.py
    :linenos:
