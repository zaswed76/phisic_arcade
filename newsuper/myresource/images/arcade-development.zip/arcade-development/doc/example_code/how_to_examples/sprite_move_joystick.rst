:orphan:

.. _sprite_move_joystick:

Game Controller/Joystick
========================

.. literalinclude:: ../../../arcade/examples/sprite_move_joystick.py
    :caption: sprite_move_joystick.py
    :linenos:
