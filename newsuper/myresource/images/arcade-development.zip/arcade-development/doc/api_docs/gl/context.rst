
.. py:currentmodule:: arcade

Context
=======

Context
-------

.. autoclass:: arcade.gl.Context
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

ContextStats
------------

.. autoclass:: arcade.gl.context.ContextStats
   :members:
   :member-order: bysource

Limits
------

.. autoclass:: arcade.gl.context.Limits
   :members:
   :undoc-members:
   :member-order: bysource
