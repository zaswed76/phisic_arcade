:orphan:

.. _pymunk_demo_top_down:

Pymunk Demo - Top Down
======================

.. image:: pymunk_demo_top_down.png
    :width: 600px
    :align: center
    :alt: Pymunk Demo - Top Down

.. literalinclude:: ../../../arcade/examples/pymunk_demo_top_down.py
    :caption: pymunk_demo_top_down.py
    :linenos:
