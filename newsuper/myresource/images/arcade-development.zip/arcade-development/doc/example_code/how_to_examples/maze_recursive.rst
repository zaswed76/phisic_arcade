:orphan:

.. _maze_recursive:

Creating a Recursive Maze
=========================

.. image:: maze_recursive.png
    :width: 600px
    :align: center
    :alt: Screen shot of a maze created by recursion

.. literalinclude:: ../../../arcade/examples/maze_recursive.py
    :caption: maze_recursive.py
    :linenos:
