:orphan:

.. _view_pause_screen:

Using Views for a Pause Screen
==============================

You might also want to check out :ref:`view-tutorial`.

.. literalinclude:: ../../../arcade/examples/view_pause_screen.py
    :caption: view_pause_screen.py
    :linenos:
