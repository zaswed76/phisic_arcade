:orphan:

.. _follow_path:

Sprites That Follow a Path
==========================

.. image:: follow_path.png
    :width: 600px
    :align: center
    :alt: Screen shot of a sprite following a path

.. literalinclude:: ../../../arcade/examples/follow_path.py
    :caption: follow_path.py
    :linenos:
