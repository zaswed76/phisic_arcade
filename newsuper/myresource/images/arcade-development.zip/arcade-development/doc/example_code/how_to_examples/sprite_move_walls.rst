:orphan:

.. _sprite_move_walls:

Move with Walls
===============

.. image:: sprite_move_walls.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to detect wall collisions

.. literalinclude:: ../../../arcade/examples/sprite_move_walls.py
    :caption: sprite_move_walls.py
    :linenos:
