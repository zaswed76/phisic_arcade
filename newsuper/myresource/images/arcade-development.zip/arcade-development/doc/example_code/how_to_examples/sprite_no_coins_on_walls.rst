:orphan:

.. _sprite_no_coins_on_walls:

Randomly Place Coins, But Away From Walls And Other Coins
=========================================================

.. image:: sprite_no_coins_on_walls.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to collect coins. But no coins on walls or each other

.. literalinclude:: ../../../arcade/examples/sprite_no_coins_on_walls.py
    :caption: sprite_no_coins_on_walls.py
    :linenos:
    :emphasize-lines: 83-107
