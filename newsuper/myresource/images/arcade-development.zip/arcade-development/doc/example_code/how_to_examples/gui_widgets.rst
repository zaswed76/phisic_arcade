:orphan:

.. _gui_widgets:

GUI Widgets
===========

.. image:: gui_widgets.png
    :width: 600px
    :align: center
    :alt: Screen shot GUI Widgets

.. literalinclude:: ../../../arcade/examples/gui_widgets.py
    :caption: gui_widgets.py
    :linenos:
