:orphan:

.. _gui_scrollable_text:

GUI Scrollable Text
===================

For an introduction the GUI system, see :ref:`gui_concepts`.

.. image:: gui_scrollable_text.png
    :width: 600px
    :align: center
    :alt: Screen shot gui_scrollable_text in action

.. literalinclude:: ../../../arcade/examples/gui_scrollable_text.py
    :caption: gui_scrollable_text.py
    :linenos:
