:orphan:

.. _sprite_explosion_bitmapped:

Sprite Explosions Bitmapped
===========================

.. image:: sprite_explosion_bitmapped.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to shoot things

.. literalinclude:: ../../../arcade/examples/sprite_explosion_bitmapped.py
    :caption: sprite_explosion_bitmapped.py
    :linenos:
    :emphasize-lines: 27, 32-50, 81-93, 109, 149, 190, 201-212

