:orphan:

.. _shape_list_demo_skylines:

Shape List - Skylines
=====================

.. image:: shape_list_demo_skylines.png
    :width: 600px
    :align: center
    :alt: Screenshot of using shape list to create a moving skyline

.. literalinclude:: ../../../arcade/examples/shape_list_demo_skylines.py
    :caption: shape_list_demo_skylines.py
    :linenos:
