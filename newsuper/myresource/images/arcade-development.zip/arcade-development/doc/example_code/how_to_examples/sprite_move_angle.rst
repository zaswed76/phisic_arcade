:orphan:

.. _sprite_move_angle:

Move Sprites By Angle
=====================

.. image:: sprite_move_angle.png
    :width: 600px
    :align: center
    :alt: Screen shot of moving a sprite by keyboard and angle

.. literalinclude:: ../../../arcade/examples/sprite_move_angle.py
    :caption: sprite_move_angle.py
    :linenos:
