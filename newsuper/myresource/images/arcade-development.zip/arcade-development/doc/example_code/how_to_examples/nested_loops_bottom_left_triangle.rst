:orphan:

.. _nested_loops_bottom_left_triangle:

Bottom Left Triangle
====================

.. image:: nested_loops_bottom_left_triangle.png
    :width: 255px
    :height: 255px
    :align: center
    :alt: Draw a triangle with nested loops.

.. literalinclude:: ../../../arcade/examples/nested_loops_bottom_left_triangle.py
    :caption: nested_loops_bottom_left_triangle.py
    :linenos:
