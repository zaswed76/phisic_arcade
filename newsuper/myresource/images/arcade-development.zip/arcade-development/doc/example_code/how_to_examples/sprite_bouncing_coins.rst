:orphan:

.. _sprite_bouncing_coins:

Sprite Bouncing Coins
=====================

.. image:: sprite_bouncing_coins.png
    :width: 600px
    :align: center
    :alt: Screen shot of simple bouncing coins

.. literalinclude:: ../../../arcade/examples/sprite_bouncing_coins.py
    :caption: sprite_bouncing_coins.py
    :linenos:
