:orphan:

.. _pymunk_pegboard:

Pymunk Physics Engine - Pegboard
================================

This uses the Pymunk physics engine to simulate balls falling on a pegboard.


.. image:: pymunk_pegboard.png
    :width: 600px
    :align: center
    :alt: Screenshot of pegboard example.


.. literalinclude:: ../../../arcade/examples/pymunk_pegboard.py
    :caption: pybmunk_pegboard.py
    :linenos:

