:orphan:

.. _slime_invaders:

Slime Invaders
==============

.. image:: slime_invaders.png
    :width: 600px
    :align: center
    :alt: Screenshot of Slime Invaders

.. literalinclude:: ../../../arcade/examples/slime_invaders.py
    :caption: slime_invaders.py
    :linenos:
