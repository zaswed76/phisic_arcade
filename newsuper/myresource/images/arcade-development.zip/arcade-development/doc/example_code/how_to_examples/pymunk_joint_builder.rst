:orphan:

.. _pymunk_joint_builder:

Pymunk Physics Engine - Joint Builder
=====================================

This uses the Pymunk physics engine to simulate items with joints


.. image:: pymunk_joint_builder.png
    :width: 600px
    :align: center
    :alt: Screenshot of pegboard example.


.. literalinclude:: ../../../arcade/examples/pymunk_joint_builder.py
    :caption: pymunk_joint_builder.py
    :linenos:

