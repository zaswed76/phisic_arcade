
.. py:currentmodule:: arcade

Exceptions
----------

.. autoclass:: arcade.gl.ShaderException
   :members:
   :undoc-members:
   :show-inheritance:
