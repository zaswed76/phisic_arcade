:orphan:

.. _sprite_bullets_aimed:

Aim and Shoot Bullets
=====================

.. image:: sprite_bullets_aimed.png
    :width: 600px
    :align: center
    :alt: Screenshot of using sprites to shoot things

.. literalinclude:: ../../../arcade/examples/sprite_bullets_aimed.py
    :caption: sprite_bullets_aimed.py
    :linenos:
