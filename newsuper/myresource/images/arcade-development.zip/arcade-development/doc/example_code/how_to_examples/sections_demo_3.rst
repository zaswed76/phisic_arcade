:orphan:

.. _sections_demo_3:

Sections Demo 3
===============

.. image:: sections_demo_3.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sections

.. literalinclude:: ../../../arcade/examples/sections_demo_3.py
    :caption: sections_demo_3.py
    :linenos:
