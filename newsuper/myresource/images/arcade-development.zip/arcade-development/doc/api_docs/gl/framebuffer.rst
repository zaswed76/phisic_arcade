
.. py:currentmodule:: arcade

Framebuffer
===========

FrameBuffer
-----------

.. autoclass:: arcade.gl.Framebuffer
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

DefaultFrameBuffer
------------------

.. autoclass:: arcade.gl.framebuffer.DefaultFrameBuffer
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource
