:orphan:

.. _sprite_bullets_enemy_aims:

Have Enemies Aim at Player
==========================

.. image:: sprite_bullets_enemy_aims.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sprites to shoot things

.. literalinclude:: ../../../arcade/examples/sprite_bullets_enemy_aims.py
    :caption: sprite_bullets_enemy_aims.py
    :linenos:
