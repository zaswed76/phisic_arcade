:orphan:

.. _tetris:

Tetris
======

.. image:: tetris.png
    :align: center
    :alt: Screenshot of Tetris clone

.. literalinclude:: ../../../arcade/examples/tetris.py
    :caption: tetris.py
    :linenos:
