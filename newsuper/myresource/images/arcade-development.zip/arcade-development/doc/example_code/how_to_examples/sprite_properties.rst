:orphan:

.. _sprite_properties:

Sprite Properties
=================

.. image:: sprite_properties.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_properties.py
    :caption: sprite_properties.py
    :linenos:
