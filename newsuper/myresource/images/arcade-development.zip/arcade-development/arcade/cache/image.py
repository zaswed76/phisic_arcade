

class WeakImageCache:

    def __init__(self):
        self._entries = {}
