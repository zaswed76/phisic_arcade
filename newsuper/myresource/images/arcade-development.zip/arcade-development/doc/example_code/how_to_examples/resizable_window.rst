:orphan:

.. _resizable_window:

Resizable Window
================

.. image:: resizable_window.png
    :width: 600px
    :align: center
    :alt: Screenshot of resizable window

.. literalinclude:: ../../../arcade/examples/resizable_window.py
    :caption: resizable_window.py
    :linenos:
