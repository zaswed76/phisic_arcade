:orphan:

.. _drawing_with_loops:

Drawing with Loops
==================

.. image:: drawing_with_loops.png
    :width: 600px
    :align: center
    :alt: Screen shot of drawing with loops example program

.. literalinclude:: ../../../arcade/examples/drawing_with_loops.py
    :caption: drawing_with_loops.py
    :linenos:
