:orphan:

.. _sprite_tiled_map_with_levels:

Work with levels and a tiled map
================================

.. image:: sprite_tiled_map_with_levels.png
    :width: 600px
    :align: center
    :alt: Screenshot of using a larger map created by the Tiled Map Editor

.. literalinclude:: ../../../arcade/examples/sprite_tiled_map_with_levels.py
    :caption: sprite_tiled_map_with_levels.py
    :linenos:
