:orphan:

.. _particle_fireworks:

Particle System - Fireworks
===========================

.. image:: particle_fireworks.png
    :width: 255px
    :height: 255px
    :align: center
    :alt: Fireworks

.. literalinclude:: ../../../arcade/examples/particle_fireworks.py
    :caption: particle_fireworks.py
    :linenos:
