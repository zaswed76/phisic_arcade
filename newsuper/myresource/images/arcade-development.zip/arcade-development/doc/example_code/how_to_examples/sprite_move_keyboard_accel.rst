:orphan:

.. _sprite_move_keyboard_accel:

Acceleration and Friction
=========================

.. image:: sprite_move_keyboard.png
    :width: 600px
    :align: center
    :alt: Screen shot of moving a sprite by keyboard

.. literalinclude:: ../../../arcade/examples/sprite_move_keyboard_accel.py
    :caption: sprite_move_keyboard_accel.py
    :linenos:
    :emphasize-lines: 24-31, 43, 46, 50, 53, 128-160
