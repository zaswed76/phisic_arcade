:orphan:

.. _procedural_caves_bsp:

Procedural Caves - Binary Space Partitioning
============================================

.. image:: procedural_caves_bsp.png
    :width: 600px
    :align: center
    :alt: Screen shot of using Binary Space Partitioning to generate caves

.. literalinclude:: ../../../arcade/examples/procedural_caves_bsp.py
    :caption: procedural_caves_bsp.py
    :linenos:
