:orphan:

.. _timer:

On-Screen Timer
===============

.. image:: timer.png
    :width: 600px
    :align: center
    :alt: Screenshot of running a timer

.. literalinclude:: ../../../arcade/examples/timer.py
    :caption: timer.py
    :linenos:
