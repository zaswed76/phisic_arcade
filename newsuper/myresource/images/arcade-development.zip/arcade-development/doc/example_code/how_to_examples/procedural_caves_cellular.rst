:orphan:

.. _procedural_caves_cellular:

Procedural Caves - Cellular Automata
====================================

.. image:: procedural_caves_cellular.png
    :width: 600px
    :align: center
    :alt: Screen shot of cellular automata to generate caves

.. literalinclude:: ../../../arcade/examples/procedural_caves_cellular.py
    :caption: procedural_caves_cellular.py
    :linenos:
