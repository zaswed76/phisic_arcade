:orphan:

.. _sprite_follow_simple:

Sprites That Follow The Player
==============================

.. image:: sprite_follow_simple.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sprites to collect coins

.. literalinclude:: ../../../arcade/examples/sprite_follow_simple.py
    :caption: sprite_follow_simple.py
    :linenos:
