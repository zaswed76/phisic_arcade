:orphan:

.. _sprite_collect_coins:

Collect Coins - Mouse
=====================

This is an example showing basic sprite usage. Collect coins with your mouse, and keep score!

.. image:: sprite_collect_coins.png
    :width: 600px
    :align: center
    :alt: Screen shot of using sprites to collect coins


Source Code
-----------

.. literalinclude:: ../../../arcade/examples/sprite_collect_coins.py
    :caption: sprite_collect_coins.py
    :linenos:
