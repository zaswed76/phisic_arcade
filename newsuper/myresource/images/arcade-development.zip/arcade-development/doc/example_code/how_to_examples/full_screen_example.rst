:orphan:

.. _full_screen_example:

Full Screen Example
===================

.. image:: full_screen_example.png
    :width: 600px
    :align: center
    :alt: Screenshot of a program demoing how to use full-screen

.. literalinclude:: ../../../arcade/examples/full_screen_example.py
    :caption: full_screen_example.py
    :linenos:
