:orphan:

.. _starting_template:

Starting Template Using Window Class
====================================

.. literalinclude:: ../../../arcade/examples/starting_template.py
    :caption: starting_template.py
    :linenos:
